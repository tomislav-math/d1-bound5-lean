import D1Bound5.SmallPairGraphWitnessData26
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared26

theorem PairGraphPrepared26.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_26 smallPairB_26 anchorRoot
      (10^1100) smallPairClosure_26 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_26_checked :
    pairClosureBool smallPairA_26 smallPairB_26
      (10^1100) smallPairClosure_26 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_26 smallPairB_26 anchorRoot
    (10^1100) smallPairClosure_26 witnesses destinations PairGraphPrepared26.indexed_checked

end D1Bound5
