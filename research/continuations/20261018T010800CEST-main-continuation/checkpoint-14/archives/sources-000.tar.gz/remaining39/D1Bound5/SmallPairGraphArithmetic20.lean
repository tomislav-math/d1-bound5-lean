import D1Bound5.SmallPairGraphInputs20
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_20_checked :
    pairSeedsCoveredBool smallPairA_20 smallPairB_20
      seedRootDisk_1_1 smallPairClosure_20 = true := by
  decide +kernel

theorem smallPairFilter_20_checked :
    largePairVertices smallPairA_20 smallPairB_20 smallPairClosure_20 = smallPairLarge_20 := by
  decide +kernel

theorem smallPairLarge_20_count : smallPairLarge_20.length = 446 := by
  decide +kernel

end D1Bound5
