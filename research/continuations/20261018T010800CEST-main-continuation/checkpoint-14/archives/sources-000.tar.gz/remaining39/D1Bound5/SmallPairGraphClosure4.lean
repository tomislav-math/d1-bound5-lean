import D1Bound5.SmallPairGraphWitnessData4
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared4

theorem PairGraphPrepared4.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_4 smallPairB_4 anchorRoot
      (10^1100) smallPairClosure_4 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_4_checked :
    pairClosureBool smallPairA_4 smallPairB_4
      (10^1100) smallPairClosure_4 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_4 smallPairB_4 anchorRoot
    (10^1100) smallPairClosure_4 witnesses destinations PairGraphPrepared4.indexed_checked

end D1Bound5
