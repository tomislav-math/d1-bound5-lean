import D1Bound5.SmallPairGraphInputs42
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_42_checked :
    pairSeedsCoveredBool smallPairA_42 smallPairB_42
      seedRootDisk_1_3 smallPairClosure_42 = true := by
  decide +kernel

theorem smallPairFilter_42_checked :
    largePairVertices smallPairA_42 smallPairB_42 smallPairClosure_42 = smallPairLarge_42 := by
  decide +kernel

theorem smallPairLarge_42_count : smallPairLarge_42.length = 484 := by
  decide +kernel

end D1Bound5
