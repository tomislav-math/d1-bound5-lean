import D1Bound5.SmallPairGraphInputs2
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_2_checked :
    pairSeedsCoveredBool smallPairA_2 smallPairB_2
      seedRootDisk_0_1 smallPairClosure_2 = true := by
  decide +kernel

theorem smallPairFilter_2_checked :
    largePairVertices smallPairA_2 smallPairB_2 smallPairClosure_2 = smallPairLarge_2 := by
  decide +kernel

theorem smallPairLarge_2_count : smallPairLarge_2.length = 414 := by
  decide +kernel

end D1Bound5
