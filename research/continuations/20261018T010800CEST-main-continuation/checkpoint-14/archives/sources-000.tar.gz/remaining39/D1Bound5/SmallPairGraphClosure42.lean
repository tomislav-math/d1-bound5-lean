import D1Bound5.SmallPairGraphWitnessData42
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared42

theorem PairGraphPrepared42.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_42 smallPairB_42 anchorRoot
      (10^1100) smallPairClosure_42 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_42_checked :
    pairClosureBool smallPairA_42 smallPairB_42
      (10^1100) smallPairClosure_42 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_42 smallPairB_42 anchorRoot
    (10^1100) smallPairClosure_42 witnesses destinations PairGraphPrepared42.indexed_checked

end D1Bound5
