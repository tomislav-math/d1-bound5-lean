import D1Bound5.SmallPairGraphInputs18
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_18_checked :
    pairSeedsCoveredBool smallPairA_18 smallPairB_18
      seedRootDisk_1_1 smallPairClosure_18 = true := by
  decide +kernel

theorem smallPairFilter_18_checked :
    largePairVertices smallPairA_18 smallPairB_18 smallPairClosure_18 = smallPairLarge_18 := by
  decide +kernel

theorem smallPairLarge_18_count : smallPairLarge_18.length = 524 := by
  decide +kernel

end D1Bound5
