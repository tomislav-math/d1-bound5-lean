import D1Bound5.SmallPairGraphWitnessData44
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared44

theorem PairGraphPrepared44.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_44 smallPairB_44 anchorRoot
      (10^1100) smallPairClosure_44 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_44_checked :
    pairClosureBool smallPairA_44 smallPairB_44
      (10^1100) smallPairClosure_44 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_44 smallPairB_44 anchorRoot
    (10^1100) smallPairClosure_44 witnesses destinations PairGraphPrepared44.indexed_checked

end D1Bound5
