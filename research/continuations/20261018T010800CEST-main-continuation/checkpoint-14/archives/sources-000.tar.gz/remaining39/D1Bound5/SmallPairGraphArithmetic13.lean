import D1Bound5.SmallPairGraphInputs13
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_13_checked :
    pairSeedsCoveredBool smallPairA_13 smallPairB_13
      seedRootDisk_0_2 smallPairClosure_13 = true := by
  decide +kernel

theorem smallPairFilter_13_checked :
    largePairVertices smallPairA_13 smallPairB_13 smallPairClosure_13 = smallPairLarge_13 := by
  decide +kernel

theorem smallPairLarge_13_count : smallPairLarge_13.length = 496 := by
  decide +kernel

end D1Bound5
