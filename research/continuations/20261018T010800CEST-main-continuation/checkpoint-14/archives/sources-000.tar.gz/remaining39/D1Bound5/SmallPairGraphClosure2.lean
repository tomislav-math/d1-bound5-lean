import D1Bound5.SmallPairGraphWitnessData2
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared2

theorem PairGraphPrepared2.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_2 smallPairB_2 anchorRoot
      (10^1100) smallPairClosure_2 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_2_checked :
    pairClosureBool smallPairA_2 smallPairB_2
      (10^1100) smallPairClosure_2 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_2 smallPairB_2 anchorRoot
    (10^1100) smallPairClosure_2 witnesses destinations PairGraphPrepared2.indexed_checked

end D1Bound5
