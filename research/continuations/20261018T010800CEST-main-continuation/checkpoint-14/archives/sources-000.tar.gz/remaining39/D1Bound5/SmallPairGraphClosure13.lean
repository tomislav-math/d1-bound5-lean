import D1Bound5.SmallPairGraphWitnessData13
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared13

theorem PairGraphPrepared13.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_13 smallPairB_13 anchorRoot
      (10^1100) smallPairClosure_13 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_13_checked :
    pairClosureBool smallPairA_13 smallPairB_13
      (10^1100) smallPairClosure_13 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_13 smallPairB_13 anchorRoot
    (10^1100) smallPairClosure_13 witnesses destinations PairGraphPrepared13.indexed_checked

end D1Bound5
