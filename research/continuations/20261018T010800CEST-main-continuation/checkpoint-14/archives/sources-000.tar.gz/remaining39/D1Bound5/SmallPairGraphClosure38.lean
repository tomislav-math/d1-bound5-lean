import D1Bound5.SmallPairGraphWitnessData38
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared38

theorem PairGraphPrepared38.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_38 smallPairB_38 anchorRoot
      (10^1100) smallPairClosure_38 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_38_checked :
    pairClosureBool smallPairA_38 smallPairB_38
      (10^1100) smallPairClosure_38 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_38 smallPairB_38 anchorRoot
    (10^1100) smallPairClosure_38 witnesses destinations PairGraphPrepared38.indexed_checked

end D1Bound5
