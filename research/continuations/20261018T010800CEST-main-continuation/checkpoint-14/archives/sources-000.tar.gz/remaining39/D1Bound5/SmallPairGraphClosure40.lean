import D1Bound5.SmallPairGraphWitnessData40
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared40

theorem PairGraphPrepared40.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_40 smallPairB_40 anchorRoot
      (10^1100) smallPairClosure_40 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_40_checked :
    pairClosureBool smallPairA_40 smallPairB_40
      (10^1100) smallPairClosure_40 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_40 smallPairB_40 anchorRoot
    (10^1100) smallPairClosure_40 witnesses destinations PairGraphPrepared40.indexed_checked

end D1Bound5
