import D1Bound5.SmallPairGraphWitnessData20
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared20

theorem PairGraphPrepared20.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_20 smallPairB_20 anchorRoot
      (10^1100) smallPairClosure_20 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_20_checked :
    pairClosureBool smallPairA_20 smallPairB_20
      (10^1100) smallPairClosure_20 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_20 smallPairB_20 anchorRoot
    (10^1100) smallPairClosure_20 witnesses destinations PairGraphPrepared20.indexed_checked

end D1Bound5
