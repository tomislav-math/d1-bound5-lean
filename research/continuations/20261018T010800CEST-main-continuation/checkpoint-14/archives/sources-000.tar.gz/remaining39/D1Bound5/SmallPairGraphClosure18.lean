import D1Bound5.SmallPairGraphWitnessData18
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared18

theorem PairGraphPrepared18.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_18 smallPairB_18 anchorRoot
      (10^1100) smallPairClosure_18 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_18_checked :
    pairClosureBool smallPairA_18 smallPairB_18
      (10^1100) smallPairClosure_18 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_18 smallPairB_18 anchorRoot
    (10^1100) smallPairClosure_18 witnesses destinations PairGraphPrepared18.indexed_checked

end D1Bound5
