import D1Bound5.SmallPairGraphInputs38
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_38_checked :
    pairSeedsCoveredBool smallPairA_38 smallPairB_38
      seedRootDisk_1_2 smallPairClosure_38 = true := by
  decide +kernel

theorem smallPairFilter_38_checked :
    largePairVertices smallPairA_38 smallPairB_38 smallPairClosure_38 = smallPairLarge_38 := by
  decide +kernel

theorem smallPairLarge_38_count : smallPairLarge_38.length = 561 := by
  decide +kernel

end D1Bound5
