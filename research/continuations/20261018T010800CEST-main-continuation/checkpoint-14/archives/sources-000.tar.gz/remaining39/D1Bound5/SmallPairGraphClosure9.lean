import D1Bound5.SmallPairGraphWitnessData9
import D1Bound5.PairClosureIndexedWitness

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open PairGraphPrepared9

theorem PairGraphPrepared9.indexed_checked :
    pairClosureIndexedWitnessBool smallPairA_9 smallPairB_9 anchorRoot
      (10^1100) smallPairClosure_9 witnesses destinations = true := by
  decide +kernel

theorem smallPairClosure_9_checked :
    pairClosureBool smallPairA_9 smallPairB_9
      (10^1100) smallPairClosure_9 = true :=
  pairClosureBool_of_indexed_witness_checked (by decide) smallPairA_9 smallPairB_9 anchorRoot
    (10^1100) smallPairClosure_9 witnesses destinations PairGraphPrepared9.indexed_checked

end D1Bound5
