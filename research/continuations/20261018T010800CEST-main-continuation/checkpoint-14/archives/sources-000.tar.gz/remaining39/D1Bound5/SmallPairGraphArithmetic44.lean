import D1Bound5.SmallPairGraphInputs44
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_44_checked :
    pairSeedsCoveredBool smallPairA_44 smallPairB_44
      seedRootDisk_1_4 smallPairClosure_44 = true := by
  decide +kernel

theorem smallPairFilter_44_checked :
    largePairVertices smallPairA_44 smallPairB_44 smallPairClosure_44 = smallPairLarge_44 := by
  decide +kernel

theorem smallPairLarge_44_count : smallPairLarge_44.length = 440 := by
  decide +kernel

end D1Bound5
