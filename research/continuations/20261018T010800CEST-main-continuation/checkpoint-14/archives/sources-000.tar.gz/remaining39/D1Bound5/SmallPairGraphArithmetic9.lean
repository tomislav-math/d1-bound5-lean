import D1Bound5.SmallPairGraphInputs9
import D1Bound5.TwoSmallSeedDisks

namespace D1Bound5
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem smallPairSeeds_9_checked :
    pairSeedsCoveredBool smallPairA_9 smallPairB_9
      seedRootDisk_0_1 smallPairClosure_9 = true := by
  decide +kernel

theorem smallPairFilter_9_checked :
    largePairVertices smallPairA_9 smallPairB_9 smallPairClosure_9 = smallPairLarge_9 := by
  decide +kernel

theorem smallPairLarge_9_count : smallPairLarge_9.length = 438 := by
  decide +kernel

end D1Bound5
