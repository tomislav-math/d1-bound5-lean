import D1Bound5.SmallPairLightLeft44
import D1Bound5.SmallPairLightRight44
import D1Bound5.PairLightArithmeticBridge
import D1Bound5.SmallPairRawSelectedData44

namespace D1Bound5.PairLightPrepared44
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem sieve_eq : sieve = smallPairSieve_1_4 := by
  rfl

theorem leftVertices_eq :
    leftVertices = (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).1.map pairLightCoordinates := by
  decide +kernel

theorem leftCached_eq :
    leftCached = PairSelectedPrepared44.leftCached.map pairLightCachedCoordinates := by
  rfl

theorem leftRows_eq : leftRows = PairSelectedPrepared44.leftRows := by
  rfl

theorem left_checked :
    pairIndependentBool smallPairSieve_1_4 (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).1 = true := by
  apply pairIndependentBool_of_light_selected_floor_certificate (by decide) smallPairSieve_1_4
    (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).1 PairSelectedPrepared44.leftCached PairSelectedPrepared44.leftRows
  rw [← sieve_eq, ← leftVertices_eq, ← leftCached_eq, ← leftRows_eq]
  exact left_certificate_checked

theorem rightVertices_eq :
    rightVertices = (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).2.map pairLightCoordinates := by
  decide +kernel

theorem rightCached_eq :
    rightCached = PairSelectedPrepared44.rightCached.map pairLightCachedCoordinates := by
  rfl

theorem rightRows_eq : rightRows = PairSelectedPrepared44.rightRows := by
  rfl

theorem right_checked :
    pairIndependentBool smallPairSieve_1_4 (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).2 = true := by
  apply pairIndependentBool_of_light_selected_floor_certificate (by decide) smallPairSieve_1_4
    (pairSplitByMask smallPairLarge_44 PairGraphPrepared44.colors).2 PairSelectedPrepared44.rightCached PairSelectedPrepared44.rightRows
  rw [← sieve_eq, ← rightVertices_eq, ← rightCached_eq, ← rightRows_eq]
  exact right_certificate_checked

end D1Bound5.PairLightPrepared44
